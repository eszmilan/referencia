
<?php
// define variables and set to empty values
$firstnameErr =$lastnameErr= $emailErr = $phoneErr = $messageErr = $subErr ="";
$firstname =$lastname=$email = $phone = $message =$subject = "";
// $sub=$_POST["subject"];
// $forward=$_POST['forwardtag'];
$email_to = "eszmilan@vipmail.hu";
    $email_subject = $subject;
// $fullphone=$forward.'/'.$phone;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["firstname"])) {
    $firstnameErr = "Vezetéknév kitöltése kötelező";
  } else {
    $firstname = test_input($_POST["firstname"]);
    // check if name only contains letters and whitespace
    if (!preg_match("/^[a-zA-Z ]*$/",$firstname)) {
      $firstnameErr = "Érvénytelen formátum"; 
    }}
  
  if (empty($_POST["lastname"])) {
    $lastnameErr = "Keresztnév kitöltése kötelező";
  } else {
    $lastname = test_input($_POST["lastname"]);
    // check if name only contains letters and whitespace
    if (!preg_match("/^[a-zA-Z ]*$/",$lastname)) {
      $lastnameErr = "Érvénytelen formátum"; 
    }}
  
  if (empty($_POST["email"])) {
    $emailErr = "Email kitöltése kötelező";
  } else {
    $email = test_input($_POST["email"]);
    // check if e-mail address is well-formed
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $emailErr = "Érvénytelen formátum"; 
    }
  }
    
  if (empty($_POST["phone"])) {
    $phoneErr = "";
  } else {
    $phone = test_input($_POST["phone"]);
    // check phone number valid format
    
  }
  if (empty($_POST["message"])) {
    $messageErr = "Elfelejtettél üzenni nekünk :( ";
  } else {
    $comment = test_input($_POST["message"]);
  }
  if (empty($_POST["subject"])) {
    $subErr = "Tárgy kitöltése kötelező";
  }
 
}   


function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>