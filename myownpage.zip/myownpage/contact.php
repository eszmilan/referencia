<!DOCTYPE html>
<html>

<head>
<meta charset="utf-8"/>
  <title>Welcome to my own page</title>
  <link rel="icon" href="logo.png">

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <script src="scripts/menu.js"></script>
  <script src="scripts/phone-mask.min.js"></script>
  <link href="https://fonts.googleapis.com/css?family=Special+Elite" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=VT323" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css"
    integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
  <link rel="stylesheet" href="stylesheets/jquery.flipster.min.css">
  <link rel="stylesheet" href="stylesheets/index.css">
  <script src="scripts/jquery.flipster.min.js"></script>
  
</head>
<?php include ('form_process.php');?>
<body>
  <div class="fejlec">
    <div class="container-fluid">
      <div class="col-sm-4">
        <img src="logo.png" class="logo" width="100%" height="100%">
      </div>
      <div class="col-sm-8">
        <h1 class="factname"> Milán webműhelye </h1>
      </div>
    </div>
  </div>
  <div class="container-fluid">
    <div class="col-sm-12">
      <div class="menu" id="topNav">
        <a href="index.html">Főoldal</a>
        <a href="about.html">Rólam</a>
        <a href="news.html">Hirek</a>
        <a href="reference.html">Referenciák</a>
        <a href="../mybakery/index.html">Főzzünk együtt</a>
        <a href="contact.php" class="active">Kapcsolat</a>
        <a href="javascript:void(0);" class="icon" onclick="myFunction()">
          <i class="fa fa-bars"></i>
        </a>
      </div>
    </div>
  </div>
  
 
  <div class="content">
    <h1>Üzenj nekünk:</h1>
    <p><span class="error"> * Kötelező mezők</span></p>
    <div class="container-fluid">
      <div class="col-sm-6">
        <label>Név:</label></br>
        <form method="post" action="<?= htmlspecialchars($_SERVER["PHP_SELF"]) ?>"name="contactform">
          <input type="text" name="firstname" placeholder="Vezetéknév" value="<?php echo $firstname; ?>"/>
          <span class="error" > * <?php echo $firstnameErr;?> </span> </br>
          <input type="text" name="lastname" placeholder="Keresztnév" style="margin-top:2%;"
            value="<?php echo $lastname;?>"/>
          <span class="error"> * <?php echo $lastnameErr;?></span></br>
          <label>Üzenet tárgya:</label></br>
          <input type="text" placeholder="Tárgy" name="subject"value="<?php echo $subject;?>"/>
          <span class="error" > * <?php echo $subErr;?> </span> </br>
          
          <label>Üzenet:</label></br>
          
          <textarea name="message" id="message" cols="30" rows="5" value="<?php echo $message;?>"></textarea>
          <span class="error"> *<?php echo $messageErr;?> </span>
      </div></br>
      <div class="col-sm-6">
        <label style="margin-bottom: 2%;">Email:</label></br>
        <input type="email" name="email" placeholder="Email" value="<?php echo $email; ?>"/>
        <span class="error"> * <?php echo $emailErr; ?></span></br>
        <label>Telefon:</label></br>
        <input type="text" name="phone" placeholder="xx/xxx-xx-xx" class="masked-phone" data-phonemask="+(36) __/___-__-__"
value="<?php echo $phone; ?>"/>
        <span class="error"> <?php echo $phoneErr; ?></span></br>
        <input type="submit" name="submit" value="Elküldés" /></br>
        <input type="reset" name="reset" value="Tartalom törlése" /></br>
        </form>
        
        
      </div>
    </div>
  </div>

  <div class="lablec">
    <hr>
    <h4>Készitette:</h4>
    <p>Eszteró Milán</p>
    <div class="container-fluid">
      <div class="col-sm-6">
        <h4> <i class="fas fa-map-marker-alt"> 6720 Szeged</i></h4>
        <h4><i class="far fa-envelope"> eszmilan@vipmail.hu</i></h4>
        <h4><i class="fas fa-phone-square">+36 30/716-80-00</i></h4>
      </div>
      <div class="col-sm-6">
        <div class="aboutme">
          <h4>Rólam:</h4>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.
          </p>
        </div>
        <h1><i class="fab fa-facebook-square"></i>
          <i class="fab fa-github-square"></i>
          <i class="fab fa-linkedin"></i></h1>
      </div>
    </div>
  </div>
  
</body>

</html>