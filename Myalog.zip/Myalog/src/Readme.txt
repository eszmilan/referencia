Instruction
make new database in localhost
Database:logtest
username:root
pw:""
table:login
fields:username,password,email

download java mysql connector:https://dev.mysql.com/downloads/connector/j/
and install in windows
download Netbeans and import project and go to the libraries folder right click and press add library option.Search the MYSQL JDBC driver and add library,and if everything is done the program works.
Run program and click on registration button.Create account.The app is checking that everything is input is fine.If it is completed go back to login page and try login with this account.There is also data checking here.If all input correct the program redirect the final page.
